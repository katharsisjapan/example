#include <iostream>
using namespace std;
int n, a;
int remote(int x, int y)
{ int z = abs(x)+ abs(y);
  return z;
}
bool outof(int x, int y)
{ float b=a/2.0;
     if (x>=-b&&x<=b&&y>=-b&&y<=b)  return 0;
     //if(abs(x)<=b&&abs(y)<=b) return 0;
  return 1;
}
int main()
{ int i,k1,k2,r,min=10000000;
   cin>>n>>a;
   for(i=1;i<=n;i++)
   { cin>>k1>>k2;
     if(outof(k1,k2))
     {
       //cout << k1 << " " << k2 << endl;
        r=remote(k1,k2);
        if( min>r) min=r;
      }
   }
   if(min==10000000)min=0;
   cout<<min<<endl;
}
