#include <iostream>
using namespace std;

int main()
{long long a[1002], ans=0;
 int n,i;
 cin>>n;
 for (i=0;i<n;i++) cin>>a[i];
 a[n]=a[0];
 a[n+1]=a[1];
 for (i=0;i<n;i++)
     if (a[i]+a[i+1]+a[i+2]>ans) ans=a[i]+a[i+1]+a[i+2];
 cout<<ans<<endl;    
     return 0;
}
