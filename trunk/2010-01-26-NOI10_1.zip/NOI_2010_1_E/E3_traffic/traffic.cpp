#include<iostream>
using namespace std;

int main()
{  int x, y, z, s, t, res;
   cin >> x >> y >> z;
   s = 3600*x + 60*y + z;
   s += 3600*24;
   t = s - 3600*8;
   res = t%108;
   if (res >= 0 && res < 60) cout << "premini" << endl;
   if ((res >= 60 && res < 64) || (res >= 104 && res < 108)) cout << "izchakai" << endl;
   if (res >= 64 && res < 104) cout << "spri" << endl;
   return 0;
}
