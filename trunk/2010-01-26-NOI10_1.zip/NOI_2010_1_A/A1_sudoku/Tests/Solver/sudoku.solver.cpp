/*
TASK: sudo_ku
LANG: C++
AUTHOR: Alexander 'espr1t' Georgiev
CONTEST: National Olympiad in Informatics, Round 1 
*/

#include <cstdio>
#define SIDE 9
#define SQSIDE 3

int ma3x[SIDE][SIDE];
int have[SIDE];

void solve(char* inFile, char* outFile)
{
	FILE *in = fopen(inFile, "rt");
	for (int row = 0; row < SIDE; row++)
		for (int col = 0; col < SIDE; col++)
			fscanf(in, "%d", &ma3x[row][col]);
	fclose(in);
	
	int flag = 1;
	while(flag)
	{
		flag = 0;

		// Check rows
		for (int row = 0; row < SIDE; row++)
		{
			int cnt = 0, pos = -1;
			for (int i = 0; i < SIDE; i++) have[i] = 0;

			for (int col = 0; col < SIDE; col++)
				if (ma3x[row][col] == 0) pos = col, cnt++;
				else have[ma3x[row][col] - 1] = 1;

			if (cnt == 1) // This row is OK
			{
				for (int num = 0; num < SIDE; num++)
					if (have[num] == 0) {ma3x[row][pos] = num + 1; flag = 1; break;}
			}
		}

		// Check columns
		for (int col = 0; col < SIDE; col++)
		{
			int cnt = 0, pos = -1;
			for (int i = 0; i < SIDE; i++) have[i] = 0;

			for (int row = 0; row < SIDE; row++)
				if (ma3x[row][col] == 0) pos = row, cnt++;
				else have[ma3x[row][col] - 1] = 1;

			if (cnt == 1) // This column is OK
			{
				for (int num = 0; num < SIDE; num++)
					if (have[num] == 0) {ma3x[pos][col] = num + 1; flag = 1; break;}
			}
		}
		
		// Check squares
		for (int srow = 0; srow < SIDE; srow += SQSIDE)
		{
			for (int scol = 0; scol < SIDE; scol += SQSIDE)
			{
				int cnt = 0, offRow = -1, offCol = -1;
				for (int i = 0; i < SIDE; i++) have[i] = 0;

				for (int i = 0; i < SQSIDE; i++)
					for (int c = 0; c < SQSIDE; c++)
						if (ma3x[srow + i][scol + c] == 0) offRow = i, offCol = c, cnt++;
						else have[ma3x[srow + i][scol + c] - 1] = 1;
				
				if (cnt == 1) // This square is OK
				{
					for (int num = 0; num < SIDE; num++)
						if (have[num] == 0) {ma3x[srow + offRow][scol + offCol] = num + 1; flag = 1; break;}
				}
			}
		}
	}
	
	FILE *out = fopen(outFile, "wt");
	for (int row = 0; row < SIDE; row++)
		for (int col = 0; col < SIDE; col++)
			fprintf(out, "%d%c", ma3x[row][col], col == SIDE - 1 ? '\n' : ' ');
	fclose(out);
}

int main(void)
{
	int numTests = 10;
	for (int test = 1; test <= numTests; test++)
	{
		char inFile[32], outFile[32];
		sprintf(inFile, "sudoku.%02d.in", test);
		sprintf(outFile, "sudoku.%02d.out", test);
		solve(inFile, outFile);
	}
	return 0;
}
