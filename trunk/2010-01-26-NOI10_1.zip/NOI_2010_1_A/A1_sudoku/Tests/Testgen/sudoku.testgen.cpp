/*
TASK: sudo_ku
LANG: C++
AUTHOR: Alexander 'espr1t' Georgiev
CONTEST: National Olympiad in Informatics, Round 1 
*/

#include <cstdio>
#include <cstdlib>
#define SIDE 9
#define SQSIDE 3

int ma3x[SIDE][SIDE];
int have[SIDE];

void generate(char* inFile, char* outFile)
{
	FILE *in = fopen(inFile, "rt");
	for (int row = 0; row < SIDE; row++)
		for (int col = 0; col < SIDE; col++)
			fscanf(in, "%d", &ma3x[row][col]);
	fclose(in);
	
	int numChanges = 3 + rand() % 20;
	for (int change = 0; change < numChanges; change++)
	{
		int changeWhat = rand() % 3;
		
		if (changeWhat == 0) // Change row
		{
			int row = rand() % SIDE;
			int cnt = 0;
			for (int col = 0; col < SIDE; col++)
				if (ma3x[row][col] != 0) cnt++;
			if (cnt == SIDE) ma3x[row][rand() % SIDE] = 0;
		}
		if (changeWhat == 1) // Change column
		{
			int col = rand() % SIDE;
			int cnt = 0;
			for (int row = 0; row < SIDE; row++)
				if (ma3x[row][col] != 0) cnt++;
			if (cnt == SIDE) ma3x[rand() % SIDE][col] = 0;
		}
		if (changeWhat == 2) // Change square
		{
			int brFlag = 0;
			for (int srow = 0; srow < SIDE; srow += SQSIDE)
			{
				for (int scol = 0; scol < SIDE; scol += SQSIDE)
				{
					int cnt = 0;
					for (int offrow = 0; offrow < SQSIDE; offrow++)
						for (int offcol = 0; offcol < SQSIDE; offcol++)
							if (ma3x[srow + offrow][scol + offcol] != 0) cnt++;
					if (cnt == SIDE) {ma3x[srow + rand() % SQSIDE][scol + rand() % SQSIDE] = 0; brFlag = 1; break;}
				}
				if (brFlag) break;
			}
		}
	}
	
	FILE *out = fopen(outFile, "wt");
	for (int row = 0; row < SIDE; row++)
		for (int col = 0; col < SIDE; col++)
			fprintf(out, "%d%c", ma3x[row][col], col == SIDE - 1 ? '\n' : ' ');
	fclose(out);
}

int main(void)
{
	int numTests = 10;
	for (int test = 1; test <= numTests; test++)
	{
		char inFile[32], outFile[32];
		sprintf(inFile, "sudoku.%02d.sol", test);
		sprintf(outFile, "sudoku.%02d.in", test);
		generate(inFile, outFile);
	}
	return 0;
}
