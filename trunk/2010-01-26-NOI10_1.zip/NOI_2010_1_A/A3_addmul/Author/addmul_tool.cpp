#include <iostream>
#include <fstream>
#include <math.h>
#include <algorithm>
using namespace std;

typedef unsigned char Byte;

Byte found[10001];

Byte find(long a)
{
 long i,p;
 Byte m;
 found[0]=0;
 for (i=2;i<=a;i++)
 {
  m=255;
  for (p=(long)ceil(sqrt(i));p>1;p--)
   if (i%p==0) m=min((int)m,1+max(found[p],found[i/p]));
  for (p=(i>>1);p>=1;p--)
   m=min((int)m,1+max(found[p],found[i-p]));
  found[i]=m;
 }
 return found[a];
}

int main(void)
{int n;
 long a,b;
 char ifname[16]="addmul.000.in";
 char ofname[16]="addmul.000.sol";
 find(10000);
 cout<<"Test No: ";
 cin>>n;
 ifname[8]='0'+n/10;
 ifname[9]='0'+n%10;
 ofname[8]='0'+n/10;
 ofname[9]='0'+n%10;
 cout<<"Interval: ";
 cin>>a>>b;
 for (int i=a;i<=b;i++)
 // if (found[i]!=found[i-1] && found[i]!=found[i+1])
 if (found[i]<6)
   cout<<i<<':'<<(int)found[i-1]<<' '<<(int)found[i]<<' '<<(int)found[i+1]<<endl;
 cout<<"Choice: ";
 cin>>n;
 ofstream fin(ifname);
 fin<<n<<endl;
 ofstream fout(ofname);
 fout<<(int)found[n]<<endl;
 return 0;
}
