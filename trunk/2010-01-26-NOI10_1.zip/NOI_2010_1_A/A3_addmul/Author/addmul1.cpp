#include <iostream>
#include <math.h>
#include <algorithm>
using namespace std;

typedef unsigned char Byte;

Byte found[10001]={0};

Byte find (long a)
{
 long i;
 if (a==1) return 0;
 if (found[a]) return found[a];
 Byte m=255;
 for (i=2;i<=sqrt(a);i++) if (a%i==0)
  m=min((int)m,max(find(i),find(a/i))+1);
 for (i=1;i<=a/2;i++)
  m=min((int)m,max(find(i),find(a-i))+1);
 found[a]=m;
 return m;
}

int main(void)
{
 long n;
 cin>>n;
 cout<<(int)find(n)<<endl;
 return 0;
}
