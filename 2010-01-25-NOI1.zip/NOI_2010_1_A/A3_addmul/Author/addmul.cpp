#include <iostream>
#include <math.h>
#include <algorithm>
using namespace std;

typedef unsigned char Byte;

Byte found[10001];

Byte find(long a)
{
 long i,p;
 Byte m;
 found[0]=0;
 for (i=2;i<=a;i++)
 {
  m=255;
  for (p=(long)ceil(sqrt(i));p>1;p--)
   if (i%p==0) m=min((int)m,1+max(found[p],found[i/p]));
  for (p=(i>>1);p>=1;p--)
   m=min((int)m,1+max(found[p],found[i-p]));
  found[i]=m;
 }
 return found[a];
}

int main(void)
{
 long n;
 cin>>n;
 cout<<(int)find(n)<<endl;
 return 0;
}
