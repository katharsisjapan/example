#include <stdio.h>
#include <string.h>
#include <stdlib.h>
typedef struct
{unsigned long *bits;
 unsigned long cnt;
} MySet;
MySet Data;
int readerr=0;
unsigned long res;
void initSet(MySet *s,unsigned long Max)
{
 s->cnt=0;
 s->bits= (unsigned long *) malloc((Max>>3)+1);
 memset(s->bits,0,(Max>>3)+1);
}
int getBit(unsigned long n,MySet *s)
{
 unsigned long No=n >> 5;
 unsigned long bitNo= n & (unsigned long)(31);
 unsigned long mask = ((unsigned long)1)<<bitNo;
 return (s->bits[No]&mask);
}
int setBit(unsigned long n,MySet *s)
{
 if (getBit(n,s)) return 0;
 unsigned long No=n >> 5;
 unsigned long bitNo= n & (unsigned long)(31);
 unsigned long mask = ((unsigned long)1)<<bitNo;
 s->bits[No]|=mask;
 s->cnt++;
 return 1;
}
unsigned long Code(const char *s)
{unsigned long r=0;
 while (*s) {r<<=2;r|=(*s-'A');s++;}
 return r;
}
int checkStr(const char *s)
{
 if (!*s) return 0;
 while (*s){if (*s<'A' || *s>'D') return 0;
            s++;
           }
 return 1;
}
unsigned long inp(int n,unsigned int len,FILE *f)
{
    char b[64];
    int i;
    unsigned long r=0,d;
    for (i=0;i<n;i++)
    {
     fscanf(f,"%32s",b);
     if (feof(f)) {printf("0\nNot enough output lines.\n");
                   readerr=1;
                   return 0;
                  }
     if (strlen(b)!=len){printf("0\nLine #%d not correct.\n",i+1);
                         readerr=1;
                         return 0;
                        }
     if (!checkStr(b)){printf("0\nLine #%d not correct.\n",i+1);
                       readerr=1;
                       return 0;
                      }
     d=Code(b);
     if (d==res){printf("0\nLine #%d: the result should not be included.\n",i+1);
                        readerr=1;
                        return 0;
                       }
     if (!setBit(d,&Data)){printf("0\nWord %s repeated.\n",b);
                           readerr=1;
                           return 0;
                          }
     r^=d;
    }
    return r;
}
int main(int argc, char **argv)
{
 FILE *fin, *fcomp;
 int n;
 unsigned long comp;
 unsigned int len;
 char buf[64];
 if (argc!=4)
 {printf("Argument error\n");
  return 0;
 }
 if (!(fin = fopen(argv[1], "r")))      // input file
 {printf("Cannot open input.\n");
  return 0;
 }
 buf[0]=0;
 fscanf(fin,"%60s",buf);
 res=Code(buf);
 fscanf(fin,"%d",&n);
 fclose(fin);
 if (!(fcomp = fopen(argv[2], "r")))    // competitor file
 {printf("0\nCannot open result.\n");
  fclose(fin);
  return 0;
 }
 len=strlen(buf);
 initSet(&Data,1<<(2*len));
 comp=inp(n,len,fin);
 free(Data.bits);
 fclose(fin);
 if (!readerr)
 {if (comp==res) printf("10\nCorrect.\n");
  else printf("0\nProduct not correct.\n");
 }
 return 0;
}
