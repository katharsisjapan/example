#include <iostream>
using namespace std;
int main()
{
    long long v, n, b ;
    cin >> v >> n;
    b = v/3;
    if (b < n) cout << "YES " << n-b << endl;
    else cout << "NO\n";
    return 0;
}

